﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Common;
using System.Security.Cryptography.X509Certificates;
using vendacarro;

namespace SAEP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            SqlConnection con = ConBanco.ObterConexao();

            string area1 = "SELECT * FROM alocacao where alocacao.area = 1";
            string area2 = "SELECT * FROM alocacao where alocacao.area = 2";
            string area3 = "SELECT * FROM alocacao where alocacao.area = 3";
            string area4 = "SELECT * FROM alocacao where alocacao.area = 4";
            string area5 = "SELECT * FROM alocacao where alocacao.area = 5";
            string area6 = "SELECT * FROM alocacao where alocacao.area = 6";
            string area7 = "SELECT * FROM alocacao where alocacao.area = 7";
            string area8 = "SELECT * FROM alocacao where alocacao.area = 8";
            string area9 = "SELECT * FROM alocacao where alocacao.area = 9";
            string area10 = "SELECT * FROM alocacao where alocacao.area = 10";
            string area11 = "SELECT * FROM alocacao where alocacao.area = 11";


            SqlCommand cmd = new SqlCommand(area1, con);
            SqlDataReader ar1 = cmd.ExecuteReader();
            if (ar1.HasRows)
            {
                btn1.BackColor = Color.FromArgb(0, 0, 255);
                btn1.ForeColor = Color.FromArgb(25, 25, 112);
                ar1.Close();
            }
            else
            {
                ar1.Close();
            }

            SqlCommand cmd2 = new SqlCommand(area2, con);
            SqlDataReader ar2 = cmd2.ExecuteReader();
            if (ar2.HasRows)
            {
                btn2.BackColor = Color.FromArgb(0, 0, 255);
                btn2.ForeColor = Color.FromArgb(25, 25, 112);
                ar2.Close();
            }
            else
            {
                ar2.Close();
            }

            SqlCommand cmd3 = new SqlCommand(area3, con);
            SqlDataReader ar3 = cmd3.ExecuteReader();
            if (ar3.HasRows)
            {
                btn3.BackColor = Color.FromArgb(0, 0, 255);
                btn3.ForeColor = Color.FromArgb(25, 25, 112);
                ar3.Close();
            }
            else
            {
                ar3.Close();
            }

            SqlCommand cmd4 = new SqlCommand(area4, con);
            SqlDataReader ar4 = cmd4.ExecuteReader();
            if (ar4.HasRows)
            {
                btn4.BackColor = Color.FromArgb(0, 0, 255);
                btn4.ForeColor = Color.FromArgb(25, 25, 112);
                ar4.Close();
            }
            else
            {
                ar4.Close();
            }

            SqlCommand cmd5 = new SqlCommand(area5, con);
            SqlDataReader ar5 = cmd5.ExecuteReader();
            if (ar5.HasRows)
            {
                btn5.BackColor = Color.FromArgb(0, 0, 255);
                btn5.ForeColor = Color.FromArgb(25, 25, 112);
                ar5.Close();
            }
            else
            {
                ar5.Close();
            }

            SqlCommand cmd6 = new SqlCommand(area6, con);
            SqlDataReader ar6 = cmd6.ExecuteReader();
            if (ar6.HasRows)
            {
                btn6.BackColor = Color.FromArgb(0, 0, 255);
                btn6.ForeColor = Color.FromArgb(25, 25, 112);
                ar6.Close();
            }
            else
            {
                ar6.Close();
            }

            SqlCommand cmd7 = new SqlCommand(area7, con);
            SqlDataReader ar7 = cmd7.ExecuteReader();
            if (ar7.HasRows)
            {
                btn7.BackColor = Color.FromArgb(0, 0, 255);
                btn7.ForeColor = Color.FromArgb(25, 25, 112);
                ar7.Close();
            }
            else
            {
                ar7.Close();
            }

            SqlCommand cmd8 = new SqlCommand(area8, con);
            SqlDataReader ar8 = cmd8.ExecuteReader();
            if (ar8.HasRows)
            {
                btn8.BackColor = Color.FromArgb(0, 0, 255);
                btn8.ForeColor = Color.FromArgb(25, 25, 112);
                ar8.Close();
            }
            else
            {
                ar8.Close();
            }

            SqlCommand cmd9 = new SqlCommand(area9, con);
            SqlDataReader ar9 = cmd9.ExecuteReader();
            if (ar9.HasRows)
            {
                btn9.BackColor = Color.FromArgb(0, 0, 255);
                btn9.ForeColor = Color.FromArgb(25, 25, 112);
                ar9.Close();
            }
            else
            {
                ar9.Close();
            }

            SqlCommand cmd10 = new SqlCommand(area10, con);
            SqlDataReader ar10 = cmd10.ExecuteReader();
            if (ar10.HasRows)
            {
                btn10.BackColor = Color.FromArgb(0, 0, 255);
                btn10.ForeColor = Color.FromArgb(25, 25, 112);
                ar10.Close();
            }
            else
            {
                ar10.Close();
            }

            SqlCommand cmd11 = new SqlCommand(area11, con);
            SqlDataReader ar11 = cmd11.ExecuteReader();
            if (ar11.HasRows)
            {
                btn11.BackColor = Color.FromArgb(0, 0, 255);
                btn11.ForeColor = Color.FromArgb(25, 25, 112);
                ar11.Close();
            }
            else
            {
                ar11.Close();
            }
            con.Close();
        }


        private void button8_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 7.ToString();
            abrir.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 8.ToString();
            abrir.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {

            Form2 abrir = new Form2();
            abrir.lblArea.Text = 3.ToString();
            abrir.ShowDialog();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 10.ToString();
            abrir.ShowDialog();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
           Form2 abrir = new Form2();
            abrir.Text = 1.ToString();
            abrir.ShowDialog();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 2.ToString();
            abrir.ShowDialog();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 4.ToString();
            abrir.ShowDialog();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 5.ToString();
            abrir.ShowDialog();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 6.ToString();
            abrir.ShowDialog();

        }

        private void btn11_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 11.ToString();
            abrir.ShowDialog();
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            Form2 abrir = new Form2();
            abrir.lblArea.Text = 9.ToString();
            abrir.ShowDialog();
        }
    }
}
